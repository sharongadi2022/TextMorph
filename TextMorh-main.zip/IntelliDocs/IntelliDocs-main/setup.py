from setuptools import setup
import os

with open('requirements.txt') as f:
    required = f.read().splitlines()

setup(
    name='IntelliDocs',
    version='1.0.0',
    packages=[''],
    install_requires=[required],
    url='',
    license='',
    author='IntelliDocs',
    author_email='rishixc@gmail.com'
    description=''
)
